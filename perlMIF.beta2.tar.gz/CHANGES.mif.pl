Revision History for mif.pl
-----------------------------

Special thanks to,

    harward@convex.com (Ken Harward)

For helping me with Frame MIF and giving comments.


=============================================================================
1.0.1	(July 5, 1994)

    Bug Fixes
	o MIFescape_string what translating '"' to \Q instead of '`'.  This
	  has been fixed.


=============================================================================
1.0.0	(June 13, 1994)

    The original version.
